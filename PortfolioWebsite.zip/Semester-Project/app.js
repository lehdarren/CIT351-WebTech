//********JUST COPY AS IS********
//
//
// SERVER SET-UP - 
//

// initialize Express
var express = require('express');  // MUST npm install express !!
var app = express();  // execute the express function

// Set up to handle uploaded 'static' HTML, CSS, images 
//
// Create path and provide cross-platform path specification using PATH
var path = require("path");  //MUST npm install path

// Resolve paths to imported HTML files "/public"
app.use(express.static(path.join (__dirname, 'public')));  //__dirname will resolve to your project folder

// end of handling of static files


// Set up to handle dynamic responses using templates 
//
// Set ejs as templating engine
app.set('view engine', 'ejs');   // MUST npm install ejs !!

// Tell Express that your ejs files reside inside 'views' folder
app.set('views', path.join (__dirname, 'views')); //__dirname will resolve to your project folder

// Set up package to parser the body of a POST request
var bodyParser = require('body-parser');   // MUST npm install body-parser !!
app.use(bodyParser.urlencoded({extended: true}));

//set up package to send emails
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
	service: 'gmail',
	auth: {
		user: 'fakeemail@email.com',
		pass: 'This is just filler, password no longer works'
	}
});
//
//********END OF COPY AS IS**********
//


// --------------------
// ROUTES  URL -> web server space - conditional for handling 'HTTP request'
// ---------------------

// TEMPORARY LIST bc no database when we did not have database
//var todoList = ["walk the dog", "buy eggs", "throw away bread", "make coffee"];  // GLOBAL
//

// for intial debugging - test of database - comment out later
//ToDo.create(
//	{ 
//	todo: "Buy Milk", 
//	priority: 1
//	}, function (err, newToDo) {
//		if (err) {
//			console.log (err);
//		} else {
//			console.log ("New ToDo: " + newToDo);
//		}
//	});
	
//make request from root or “/” -> Serve a static HTML page
app.get("/", function(req, res) {
	res.sendFile ("/index.html");   // MUST import 'index.html' to 'public folder' 
}); // end app.get

// POST request coming from button in 'todo.ejs' -- SENT DATA THROUGH
app.post("/sendemail", function (req, res) {
	// get data from form and add to ToDoDB
	// MUST be same var name as in todo.ejs	
	var emailAddress = req.body.EmailAddress;  // extract email address value from request body
	var emailSubject = req.body.SubjectTitle;  // extract subject value from request body
	var emailBody = req.body.MessageBody; 	   // extract message body value from request body
	
	var mailOptions = {
		from: emailAddress,
		to: 'hydrafirestorm@gmail.com',
		subject: emailSubject,
		text: emailAddress + '\n' + emailBody
	};
	
	transporter.sendMail(mailOptions, function(error, info) {
		if (error) {
			console.log(error);
		} else {
			console.log('Email sent: ' + info.response);
		}
	})
	
	res.redirect('back');
	
}); // end app.post/sendemail

//
//last ROUTE - ERROR HANDLER
//
// handle "splat" - illegal request made to MY server (URL)
app.get("*", function(req, res) {
	res.send("OH My Error - Page not found");
}); // app.get *

//
// START SERVER
//
// Tell Express to listen for HTTP requests
app.listen(3000, function (){
	console.log("Server has started");
});

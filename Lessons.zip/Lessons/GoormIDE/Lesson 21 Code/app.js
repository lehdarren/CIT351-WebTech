
//********JUST COPY AS IS********
//
//
// SERVER SET-UP - 
//

// initialize Express
var express = require('express');  // MUST npm install express !!
var app = express();  // execute the express function

// Set up to handle uploaded 'static' HTML 
//
// Create path and provide cross-platform path specification using PATH
var path = require("path");

// Resolve paths to imported HTML files "/public"
app.use(express.static(path.join (__dirname, 'public')));  //__dirname will resolve to your project folder

// end of handling of static files


// Set up to handle dynamic responses using templates 
//
// Set ejs as templating engine
app.set('view engine', 'ejs');   // MUST npm install ejs !!

// Tell Express that your ejs files reside inside 'views' folder
app.set('views', path.join (__dirname, 'views')); //__dirname will resolve to your project folder

// Set up package to parser the body of a POST request
var bodyParser = require('body-parser');   // MUST npm install body-parser !!
app.use(bodyParser.urlencoded({extended: true}));

//
//********END OF COPY AS IS**********
//


// --------------------
// ROUTES  URL -> web server space - conditional for handling 'HTTP request'
// ---------------------

// TEMPORARY LIST bc no database yet
var todoList = ["milk", "eggs", "bread", "coffee"];  // GLOBAL
//

//make request from root or “/” -> Serve a static HTML page
app.get("/", function(req, res) {
	res.sendFile ("/index.html");   // MUST import 'index.html' to 'public folder' 
});

// POST request coming from button in 'todo.ejs' -- SENT DATA THROUGH
app.post("/addToDo", function (req, res) {
	
	// MUST be same var name 'newToDo' as in todo.ejs	
	var ToDoItem = req.body.newToDo;  // extract newToDo value from request body
	
	// adding new 'todo' to list 'todo'
	todoList.push(ToDoItem);   // the list is GLOBAL
	
	// redirect to route with printout and form to add	
	res.redirect ("todo");  
});

//request from browser to '/todo.ejs' -> create a HTML page using .ejs templates
app.get("/todo", function(req, res) {
	// res.send ("You have made it to 'todo' get request");

	// todo.ejs file must be in /views folder
	// sending 'todo' object through, todoList is GLOBAL & contains list of items
	res.render("todo.ejs", {todoList: todoList}); // second todoList is arg for todo.ejs
});



//last ROUTE - ERROR HANDLER
// handle "splat" - illegal request made to MY server (URL)
app.get("*", function(req, res) {
	res.send("OH My Error - Page not found");
});



// Tell Express to listen for HTTP requests, ie. start server
app.listen(3000, function (){
	console.log("Server has started");
});


//********JUST COPY AS IS********
//
//
// SERVER SET-UP - 
//

// initialize Express
var express = require('express');  // MUST npm install express !!
var app = express();  // execute the express function

// Set up to handle uploaded 'static' HTML, CSS, images 
//
// Create path and provide cross-platform path specification using PATH
var path = require("path");  //MUST npm install path

// Resolve paths to imported HTML files "/public"
app.use(express.static(path.join (__dirname, 'public')));  //__dirname will resolve to your project folder

// end of handling of static files


// Set up to handle dynamic responses using templates 
//
// Set ejs as templating engine
app.set('view engine', 'ejs');   // MUST npm install ejs !!

// Tell Express that your ejs files reside inside 'views' folder
app.set('views', path.join (__dirname, 'views')); //__dirname will resolve to your project folder

// Set up package to parser the body of a POST request
var bodyParser = require('body-parser');   // MUST npm install body-parser !!
app.use(bodyParser.urlencoded({extended: true}));

//
// MongoDB AREA
//
// Make sure MongoDB is running in another terminal window 
//     - using './mongod' file
// database is located in the folder /data
//

var mongoose = require("mongoose");   // MUST npm install mongoose

// connect to database server
mongoose.connect("mongodb://localhost:27017/contactDB", {
	useNewUrlParser: true,
	useUnifiedTopology :true
} );

// define what a todo look like, just a pattern, can add or not use on the fly. 
var contactSchema = new mongoose.Schema({
		name: String,
		email: String,
		password: String,
		agree: String
});

// link schema to javaScript, compiled it into a model and save it in a variable Contact
// Contact has all the methods needed (create, find, delete)
var Contact = mongoose.model("Contact", contactSchema);     // "Contact" must be singlular term for items in database

//
//********END OF COPY AS IS**********
//


// --------------------
// ROUTES  URL -> web server space - conditional for handling 'HTTP request'
// ---------------------



// for initial debugging - test of database - comment out later
//Contact.create(
//	{ 
//		name: "Anita",
//		email: "a@gmail.com",
//		password: "123PW",
//	}, function (err, newContact) {
//		if (err) {
//			console.log (err);
//		} else {
//			console.log ("New Contact: " + newContact);
//		}
//	});
	
//make request from root or “/” -> Serve a static HTML page
app.get("/", function(req, res) {
	res.sendFile ("/index.html");   // MUST import 'index.html' to 'public folder' 
}); // end app.get

// GET request coming from button in 'contact.ejs'
app.get("/contact", function (req, res) {
	// get data from form and find contact in DB
	var ckName = req.query.newN;  // extract ckContact from request body

	// Find contact in database
	Contact.findOne({name: ckName}, function (err, contactItem){
		if(err) { console.log ("Error: ", err)}
				else {
					res.render("contact.ejs", {contactItem}); 
				}
		}); // end contact.find()
});  // end app.get/contact


//
//last ROUTE - ERROR HANDLER
//
// handle "splat" - illegal request made to MY server (URL)
app.get("*", function(req, res) {
	res.send("OH My Error - Page not found");
}); // app.get *

//
// START SERVER
//
// Tell Express to listen for HTTP requests
app.listen(3000, function (){
	console.log("Server has started");
});

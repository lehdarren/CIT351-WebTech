//
//********JUST COPY AS IS********
//
//
// SERVER SET-UP - 
//

// initialize Express
var express = require("express");
var app = express();  // execute the express function

// Set ejs as templating engine
app.set('view engine', 'ejs');

// Create path and provide cross-platform path specification using PATH
var path = require("path"); 

// Tell Express that your ejs files reside inside 'views' folder
app.set('views', path.join (__dirname, 'views')); //__dirname will resolve to your project folder

// Resolve paths to imported HTML files "/public"
app.use(express.static(path.join (__dirname, 'public')));  //__dirname will resolve to your project folder

//
//********END OF COPY AS IS**********
//


// --------------------
// ROUTES  URL -> web server space - conditional for handling 'HTTP request'
// ---------------------

//make request from root or “/” -> Serve a static HTML page
app.get("/", function(req, res) {
	res.sendFile("/index.html"); 
});

//make request from /contact -> create a HTML page using .ejs templates
app.get("/contact", function(req, res) {
	res.send("Welcome to Contact Page");   //HTTP Response being compiled
	//res.send ("<h1>Welcome to A Better Contact Page </h1> <h3>I do not intend to write HTML code for each response.</h>");
	//res.render("contact.ejs"); //file must be in /views folder
});
	  
// make request to compile HTML page based on color sent in GET request
app.get("/color/:color", function(req, res) {
	var hue= req.params.color;   // matches name of pattern
	//res.send ("(1) Welcome to - " + hue + " - Color");
	
	//access the template color.ejs
	res.render ("color.ejs");
});

//passing data to .ejs templates
app.get("/colorPass/:color", function(req, res) {
	var hue= req.params.color;   // matches name of pattern
	res.render ("colorPass.ejs", {hue: hue}); // pass object thru to color.ejs
});

//conditional logic
app.get("/colorIf/:color", function(req, res) {
	var hue= req.params.color;   // matches name of pattern
	res.render ("colorIf.ejs", {hue: hue}); // pass object thru to colorIf.ejs
});

//loops
app.get("/colorLoop/:color", function(req, res) {
	var hue= req.params.color;   // matches name of pattern
	res.render ("colorLoop.ejs", {hue: hue}); // pass object thru to colorLoop.ejs
});

//last ROUTE - ERROR HANDLER
// handle "splat" - illegal request made to MY server (URL)
app.get("*", function(req, res) {
	res.send("OH My Error - Page not found");
});



// Tell Express to listen for HTTP requests, ie. start server
app.listen(3000, function (){
	console.log("Server has started");
});

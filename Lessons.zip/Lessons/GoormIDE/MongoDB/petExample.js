var mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/petDB", {
	useNewUrlParser: true,
	useUnifiedTopology :true
} );

var petSchema = new mongoose.Schema({
		name: String,
		age: Number,
		temper: String
});

var Pet = mongoose.model("Pet", petSchema);

// add new pet to database

//var jasper = new Pet({
//	name: "Jasper",
//	age: 10,
//	temper: "high-strung"
//});

//jasper.save(function (err, pet)
//	{
//		if(err){
//			console.log("DIVE - DIVE, we are going down");
//			console.log (err);
//		} else {
//			console.log ("GOT IN THE NEW PET");
//			console.log (pet);
//		}
//	});

Pet.create ({			// above - var and save together
	name: "Darcy",
	age: 2,
	temper: "sweet"
	}, function (err, pet) {
	if(err){
			console.log("DIVE - DIVE, we are going down");
			console.log (err);
		} else {
			console.log ("GOT IN THE NEW PET");
			console.log (pet);
		}
});

//retrieve all cats from the DB and console.log each one

Pet.find({}, function (err, pets)
	{
		if(err){
			console.log("OH NO - the pets ran away");
		} else {
			console.log ("LISTING PETS");
			console.log (pets);
		}
	});
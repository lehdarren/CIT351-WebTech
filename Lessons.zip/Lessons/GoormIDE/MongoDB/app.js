
//********JUST COPY AS IS********
//
//
// SERVER SET-UP - 
//

// initialize Express
var express = require('express');  // MUST npm install express !!
var app = express();  // execute the express function

// Set up to handle uploaded 'static' HTML, CSS, images 
//
// Create path and provide cross-platform path specification using PATH
var path = require("path");  //MUST npm install path

// Resolve paths to imported HTML files "/public"
app.use(express.static(path.join (__dirname, 'public')));  //__dirname will resolve to your project folder

// end of handling of static files


// Set up to handle dynamic responses using templates 
//
// Set ejs as templating engine
app.set('view engine', 'ejs');   // MUST npm install ejs !!

// Tell Express that your ejs files reside inside 'views' folder
app.set('views', path.join (__dirname, 'views')); //__dirname will resolve to your project folder

// Set up package to parser the body of a POST request
var bodyParser = require('body-parser');   // MUST npm install body-parser !!
app.use(bodyParser.urlencoded({extended: true}));

//
// MongoDB AREA
//
// Make sure MongoDB is running in another terminal window 
//     - using './mongod' file
// database is located in the folder /data
//

var mongoose = require("mongoose");   // MUST npm install mongoose

// connect to database server
mongoose.connect("mongodb://localhost:27017/toDoDB", {
	useNewUrlParser: true,
	useUnifiedTopology :true
} );

// define what a todo look like, just a pattern, can add or not use on the fly. 
var toDoSchema = new mongoose.Schema({
		name: String,
		priority: String
});

// link schema to javaScript, compiled it into a model and save it in a variable ToDo
// ToDo has all the methods needed (create, find, delete)
var ToDo = mongoose.model("ToDo", toDoSchema);     // "Todo" must be singlular term for items in database

//
//********END OF COPY AS IS**********
//


// --------------------
// ROUTES  URL -> web server space - conditional for handling 'HTTP request'
// ---------------------

// TEMPORARY LIST bc no database when we did not have database
//var todoList = ["walk the dog", "buy eggs", "throw away bread", "make coffee"];  // GLOBAL
//

// for intial debugging - test of database - comment out later
//ToDo.create(
//	{ 
//	todo: "Buy Milk", 
//	priority: 1
//	}, function (err, newToDo) {
//		if (err) {
//			console.log (err);
//		} else {
//			console.log ("New ToDo: " + newToDo);
//		}
//	});
	
//make request from root or “/” -> Serve a static HTML page
app.get("/", function(req, res) {
	res.sendFile ("/index.html");   // MUST import 'index.html' to 'public folder' 
}); // end app.get

// POST request coming from button in 'todo.ejs' -- SENT DATA THROUGH
app.post("/addToDo", function (req, res) {
	// get data from form and add to ToDoDB
	// MUST be same var name as in todo.ejs	
	var newToDo = req.body.newT;  // extract newToDo value from request body
	var newPriority = req.body.newP;  // extract newToDo value from request body
	
	var newToDoEntry = {name: newToDo, priority: newPriority};
	
	// create new todo and save to database
	ToDo.create(newToDoEntry, function (err, ) {
		if (err) {
			console.log (err);
		} else {
				// redirect to route with printout and form to add	
				res.redirect ("todo"); 
		}  
	});  // end ToDo.create
}); // end app.post/addToDo

//request from browser to '/todo.ejs' -> create a HTML page using .ejs templates
app.get("/todo", function(req, res) {
	// get all todos
	ToDo.find({}, function (err, todoList){
		if(err){
			console.log(err);
		} else {
			// todo.ejs file must be in /views folder
			res.render("todo.ejs", {todoList: todoList}); // second todoList is arg for todo.ejs
		}
	}); // end ToDo.find()
});  // end app.get/todo


//
//last ROUTE - ERROR HANDLER
//
// handle "splat" - illegal request made to MY server (URL)
app.get("*", function(req, res) {
	res.send("OH My Error - Page not found");
}); // app.get *

//
// START SERVER
//
// Tell Express to listen for HTTP requests
app.listen(3000, function (){
	console.log("Server has started");
});

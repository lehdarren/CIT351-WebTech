// JavaScript for Number Guessing Game

//jQuery waiting for DOM to complete, prior to executing
$(document).ready(function() {

// JavaScript shortcuts from previous version. No longer needed
//const guesses = document.querySelector('.guesses');
const guesses = $(".guesses");
// const lastResult = document.querySelector('.lastResult');
const lastResult = $(".lastResult");
// const lowOrHi = document.querySelector('.lowOrHi');
const lowOrHi = $(".lowOrHi");

//this does not work
//const guessSubmit = document.querySelector('.guessSubmit');
const guessSubmit = $(".guessSubmit");
console.log("created guessSubmit " + guessSubmit);

// const guessField = document.querySelector('.guessField');
const guessField = $(".guessField");

// create a random number
let randomNumber = Math.floor(Math.random() * 100) + 1;

console.log("random " + randomNumber);

let guessCount = 1;  // counter for number of guesses the user made, only allowed 10
let resetButton;     // space to set up a button element during setGameOver fucntion
let appendGuessStr = "";;

// Event 'click' on guessSubmit button

//this uses anonymous function
//guessSubmit.addEventListener("click", checkGuess);
$(".guessSubmit").click(function(){
//
// checkGuess function
//
//function checkGuess() {
 // let userGuess = Number(guessField.value);
 let userGuess = Number ($(".guessField").val());

  // set up guess list the first time through
  if (guessCount === 1) {
    // guesses.textContent = 'Previous guesses: ';
    guesses.text ("Previous guesses: ");
  }
  // add current guess to guess list
  //guesses.textContent += userGuess + ' ';
   appendGuessStr = guesses.text() + " " + userGuess;
   guesses.text (appendGuessStr);

  // guess handling
  // did the user guess correctly
  if (userGuess === randomNumber) {
    //lastResult.textContent = 'Congratulations! You got it right!';
    lastResult.text  ('Congratulations! You got it right!');
    //lastResult.style.backgroundColor = 'green';
    lastResult.css("background", "green");
    //lowOrHi.textContent = '';
    lowOrHi.text ('');
    setGameOver();
  // did the user make 10 guesses
} else if (guessCount === 10) {
    //lastResult.textContent = '!!!GAME OVER!!!';
        lastResult.text ('!!!GAME OVER!!!');
    //lowOrHi.textContent = '';
        lowOrHi.text ('');
    setGameOver();
  // user guessed wrong, now display if guess was too high or low
  } else {
    //lastResult.textContent = 'Wrong!';
    lastResult.text ('Wrong!');
    //lastResult.style.backgroundColor = 'red';
    lastResult.css("background", "red");
    if(userGuess < randomNumber) {
      lowOrHi.text ('Last guess was too low!');
    } else if(userGuess > randomNumber) {
      lowOrHi.text ('Last guess was too high!');
    }
  }
  // prepare for next guess
  guessCount++;
  //guessField.value = '';
  guessField.val ('');
  guessField.focus();
}); // end checkGuess function


//
// setGameOver function
//
function setGameOver() {
  //guessField.disabled = true;
  guessField.prop("disabled", true);
  //guessSubmit.disabled = true;
  $(".guessSubmit").prop("disabled", true);
  // create new object 'button to restart the game'
  resetButton = document.createElement('button');
  resetButton.textContent = 'Start new game';
  // add new button object to the DOM
  //document.body.appendChild(resetButton);
  $("body").append(resetButton);
  // EVENT - wait for user to click the reset button, then call resetGame
  //resetButton.addEventListener('click', resetGame());
 // resetButton.on("click", resetGame());
  $(resetButton).click(function(){
//
// resetGame function
//
//function resetGame() {
  console.log("inside resetGame");
  guessCount = 1;
  //const resetParas = document.querySelectorAll('.resultParas p');
  resetParas= $('.resultParas p').children();

  for(let i = 0 ; i < resetParas.length ; i++) {
    console.log("inside for loop")
    //resetParas[i].textContent = '';
    resetParas[i].text('');
  }

  resetButton.parentNode.removeChild(resetButton);
  //$(".resetButton").remove();
  //guessField.disabled = false;
  guessField.prop("disabled", false);
  //guessSubmit.disabled = false;
  $(guessSubmit).prop("disabled", false);

  // guessField.value = '';
  guessField.val('');
  //guessField.focus();
  guessField.focus();
  //lastResult.style.backgroundColor = 'white';
  lastResult.css("background","white");
  randomNumber = Math.floor(Math.random() * 100) + 1;
});  // end resetGame function

}  // end setGameOver function

}); // end ready function
